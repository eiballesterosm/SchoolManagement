CREATE FUNCTION [dbo].[ReplaceAllSpaces]
(
    @OriginalString varchar(MAX)
)
RETURNS varchar(MAX)
AS
BEGIN
DECLARE @ResultStr varchar(MAX)
SET @ResultStr = @OriginalString
SET @ResultStr = REPLACE(@ResultStr,CHAR(9), ' ')
--Two spaces
WHILE CHARINDEX('  ', @ResultStr) > 0
BEGIN
    SET @ResultStr = REPLACE(@ResultStr, '  ', ' ')
END

RETURN @ResultStr

END

