SELECT distinct(SPECIFIC_NAME), ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE [dbo].ReplaceAllSpaces(ROUTINE_DEFINITION) LIKE '%codigo_interno%'


SELECT distinct(SPECIFIC_NAME), ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE [dbo].ReplaceAllSpaces(ROUTINE_DEFINITION) LIKE '%codigo_socio%'


SELECT distinct(SPECIFIC_NAME), ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE [dbo].ReplaceAllSpaces(ROUTINE_DEFINITION) LIKE '%codigo_layout%'

SELECT distinct(SPECIFIC_NAME)
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE ROUTINE_DEFINITION like '%update [poliza]%' or ROUTINE_DEFINITION like '%update poliza%' or  ROUTINE_DEFINITION like '%update [dbo].[poliza]%'



DECLARE @pSearchText AS VARCHAR(MAX) = '%cobro_desde%'

SELECT DISTINCT
       o.name AS Object_Name,
       o.type_desc
  FROM sys.sql_modules m
       INNER JOIN
       sys.objects o
         ON m.object_id = o.object_id
WHERE m.definition Like @pSearchText

SELECT name
FROM   sys.procedures
WHERE  Object_definition(object_id) LIKE @pSearchText

select distinct object_name(id) 
from syscomments 
where text like @pSearchText
order by object_name(id)

SELECT distinct(SPECIFIC_NAME)
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE ROUTINE_DEFINITION like @pSearchText



