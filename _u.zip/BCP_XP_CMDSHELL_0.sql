DECLARE @path_archivo VARCHAR(2000)
DECLARE @comando_bcp VARCHAR(8000)

SET @path_archivo = 'D:\CobranzaIn\reportes\gestion_cobro\test3.csv'
SET @comando_bcp = 'bcp "SELECT top 1 poliza_id FROM cobranza_P.dbo.poliza " queryout "' + @path_archivo + '" -c -t ; -r \n -T'

DECLARE @resultado_ejecucion AS INT = - 1;
EXEC @resultado_ejecucion = master..xp_cmdshell @comando_bcp