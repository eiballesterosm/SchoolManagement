SELECT SERVERPROPERTY('ComputerNamePhysicalNetBios') AS 'Is_Current_Owner'
	,SERVERPROPERTY('MachineName') AS 'MachineName'
	,CASE 
		WHEN @@ServiceName = Right(@@Servername, len(@@ServiceName))
			THEN @@Servername
		ELSE @@servername + ' \ ' + @@Servicename
		END AS '@@Servername \ Servicename'
	,CONNECTIONPROPERTY('net_transport') AS net_transport
	,CONNECTIONPROPERTY('local_tcp_port') AS local_tcp_port
	,DEC.local_tcp_port
	,CONNECTIONPROPERTY('local_net_address') AS local_net_address
	,DEC.local_net_address AS 'dec.local_net_address'
FROM sys.dm_exec_connections AS DEC
WHERE DEC.session_id = @@SPID;
