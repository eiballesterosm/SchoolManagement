DECLARE @TableName AS VARCHAR(MAX) = 'archivo_produccion_detalle'
DECLARE @ColumnList AS VARCHAR(MAX)
SELECT @ColumnList =
  (SELECT STUFF(
    (SELECT N', ' + QuoteName(CO.name)
	FROM sys.columns CO
	INNER JOIN sys.objects OBJ On OBJ.object_id = CO.object_id 
	INNER JOIN sys.schemas SCH On SCH.schema_id = OBJ.schema_id
	WHERE 1=1
	--AND s.name = 'schema'
	And OBJ.name = @TableName
	--And c.name Not In ('columnToExcept')
	ORDER BY CO.column_id 
	FOR XML PATH(''),Type)
    .value('text()[1]','nvarchar(max)'),1,2,N''))

Print @ColumnList;