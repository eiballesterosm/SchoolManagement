INSERT INTO [dbo].[archivo_produccion_detalle]
([archivo_produccion_id], [error_id], [id_proceso], [nombre], [identificacion], [plancardif], [franquicia], [poliza], [prima], [fecha_vencimiento], [fecha_inicio], [numero_tarjeta], [tipo_tarjeta], [fecha_fin_vigencia], [periodo], [codigo_producto], [llave_cabecera], [llave_detalle], [codigo_tarjeta_interno], [canal_venta], [red_producto], [socio], [prima_neta], [valor_iva], [cuota], [auxiliar_01], [auxiliar_02], [auxiliar_03], [auxiliar_04], [auxiliar_05], [auxiliar_06], [fecha_emision], [llave_homologada], [es_migracion], [fecha_recaudo], [origen_venta], [codigo_asesor], [fecha_nacimiento], [fecha_corte_inicio], [fecha_corte_fin], [amortizacion], [indicador_recaudo], [Tipo_identificacion], [Numero_recaudos], [Dias_Mora], [fecha_renovacion])

SELECT [column2], [column3], [column4], [column5], [column6], [column7], [column8], [column9], [column10], [column11], CONVERT(datetime, [column12]), [column13], [column14], CONVERT(datetime, [column15]), [column16], [column17], [column18], [column19], [column20], [column21], [column22], [column23], [column24], [column25], [column26], [column27], [column28], [column29], [column30], [column31], [column32], CONVERT(datetime, [column33]), [column34], [column35], CONVERT(datetime, [column36]), [column37], [column38], CONVERT(date, [column39]), CONVERT(date, [column40]), CONVERT(date, [column41]), [column42], [column43], [column44], [column45], [column46], [column47] from [dbo].TEST


--INSERT INTO [dbo].[archivo_produccion_detalle]
--([archivo_produccion_id], [error_id], [id_proceso], [nombre], [identificacion], [plancardif], [franquicia], [poliza], [prima], [fecha_vencimiento], [numero_tarjeta], [tipo_tarjeta],  [periodo], [codigo_producto], [llave_cabecera], [llave_detalle], [codigo_tarjeta_interno], [canal_venta], [red_producto], [socio], [prima_neta], [valor_iva], [cuota], [auxiliar_01], [auxiliar_02], [auxiliar_03], [auxiliar_04], [auxiliar_05], [auxiliar_06], [llave_homologada], [es_migracion], [origen_venta], [codigo_asesor], [amortizacion], [indicador_recaudo], [Tipo_identificacion], [Numero_recaudos], [Dias_Mora], [fecha_renovacion])

--SELECT [column2], [column3], [column4], [column5], [column6], [column7], [column8], [column9], [column10], [column11], [column13], [column14], [column16], [column17], [column18], [column19], [column20], [column21], [column22], [column23], [column24], [column25], [column26], [column27], [column28], [column29], [column30], [column31], [column32], [column34], [column35], [column37], [column38], [column42], [column43], [column44], [column45], [column46], [column47] from [dbo].TEST


--select * from archivo_produccion_detalle WHERE archivo_produccion_id = 1745
--delete from archivo_produccion_detalle WHERE archivo_produccion_id = 1745

update test
    set column3 = case when column3 = 'NULL' then Null else column3 End
	,column4 = case when column4 = 'NULL' then Null else column4 End      
	,column20 = case when column20 = 'NULL' then Null else column20 End     
	,column22 = case when column22 = 'NULL' then Null else column22 End     
	,column26 = case when column26 = 'NULL' then Null else column26 End     
	,column27 = case when column27 = 'NULL' then Null else column27 End     
	,column28 = case when column28 = 'NULL' then Null else column28 End     
	,column29 = case when column29 = 'NULL' then Null else column29 End     
	,column30 = case when column30 = 'NULL' then Null else column30 End     
	,column31 = case when column31 = 'NULL' then Null else column31 End     
	,column37 = case when column37 = 'NULL' then Null else column37 End     
	,column38 = case when column38 = 'NULL' then Null else column38 End     
	,column40 = case when column40 = 'NULL' then Null else column40 End     
	,column41 = case when column41 = 'NULL' then Null else column41 End     
	,column47 = case when column47 = 'NULL' then Null else column47 End     




DECLARE @TableName AS VARCHAR(MAX) = 'TEST'
DECLARE @ColumnList AS VARCHAR(MAX)
SELECT @ColumnList =
  (SELECT STUFF(
    (SELECT N', ' + QuoteName(CO.name)
	FROM sys.columns CO
	INNER JOIN sys.objects OBJ On OBJ.object_id = CO.object_id 
	INNER JOIN sys.schemas SCH On SCH.schema_id = OBJ.schema_id
	WHERE 1=1
	--AND s.name = 'schema'
	And OBJ.name = @TableName
	--And c.name Not In ('columnToExcept')
	ORDER BY CO.column_id 
	FOR XML PATH(''),Type)
    .value('text()[1]','nvarchar(max)'),1,2,N''))

Print @ColumnList;


	
	 


