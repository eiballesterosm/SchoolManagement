CREATE PROCEDURE [dbo].[Print] @sql VARCHAR(max)
AS
BEGIN
	DECLARE @n INT
		,@i INT = 0
		,@s INT = 0
		,-- substring start posotion
		@l INT;-- substring length

	SET @n = ceiling(len(@sql) / 8000.0);

	WHILE @i < @n
	BEGIN
		SET @l = 8000 - charindex(CHAR(13), reverse(substring(@sql, @s, 8000)));

		PRINT substring(@sql, @s, @l);

		SET @i = @i + 1;
		SET @s = @s + @l + 2;-- accumulation + CR/LF
	END

	RETURN 0
END