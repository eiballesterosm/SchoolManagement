EXEC sp_fkeys 'poliza'

SELECT OBJECT_NAME(f.parent_object_id) TableName,
	COL_NAME(fc.parent_object_id, fc.parent_column_id) ColName
FROM sys.foreign_keys AS f
INNER JOIN sys.foreign_key_columns AS fc ON f.OBJECT_ID = fc.constraint_object_id
INNER JOIN sys.tables t ON t.OBJECT_ID = fc.referenced_object_id
WHERE OBJECT_NAME(f.referenced_object_id) = 'poliza' sp_help 'poliza'

DECLARE @nombre_tabla AS VARCHAR(100) = 'red'

SELECT OBJECT_NAME(fkeys.parent_object_id) referencing_table_name
	--@nombre_tabla AS tabla
	,
	OBJECT_NAME(fkeys.constraint_object_id) nombre_llave_foranea
	--,OBJECT_NAME(fkeys.parent_object_id) referencing_table_name
	,
	COL_NAME(fkeys.parent_object_id, fkeys.parent_column_id) columna_referencia
	--,OBJECT_SCHEMA_NAME(fkeys.parent_object_id) referencing_schema_name
	,
	OBJECT_NAME(fkeys.referenced_object_id) tabla_referenciada,
	COL_NAME(fkeys.referenced_object_id, fkeys.referenced_column_id) columna_referenciada
--,OBJECT_SCHEMA_NAME(fkeys.referenced_object_id) referenced_schema_name
FROM sys.foreign_key_columns AS fkeys
--WHERE OBJECT_NAME(fkeys.parent_object_id) = @nombre_tabla
ORDER BY referencing_table_name,
	tabla_referenciada,
	columna_referencia
