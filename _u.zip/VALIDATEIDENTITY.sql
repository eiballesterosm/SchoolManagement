DECLARE @pNombreTabla AS VARCHAR(100) = 'franquicia';

SELECT OBJECTPROPERTY(OBJECT_ID(@pNombreTabla), 'TableHasIdentity');

SELECT *
FROM sys.columns
WHERE object_id = OBJECT_ID(@pNombreTabla, 'U')
	AND name = CONCAT (@pNombreTabla,'_ID');