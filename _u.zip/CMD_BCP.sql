begin try drop table ##fallabellaperucierre2021 end try begin catch end catch;

create table ##fallabellaperucierre2021 (producto varchar (4),certificado Varchar (100),fechainicio  datetime,FECHAFIN  datetime ,PRIMANETA float,iva  float,neto_REC  float, Moneda Varchar (6),FECHACONTABLE varchar(30),NARCHIVO varchar (max) null,TIPO_MOV  Varchar (100),Altura  Varchar (100))

--usar CMD
bcp ##fallabellaperucierre2021 in "D:\fallabela_peru_2021.txt" -S 10.171.173.198,1434 -c -t";" -CRAW -F2

bcp ##fallabellaperucierre2021 in "D:\fallabela_peru_2021.txt" -S10.171.173.198,1434 -c -t";" -T -CRAW -F2

select * into falabella_pt_cierre from ##fallabellaperucierre2021

