DECLARE @pSearchText AS VARCHAR(MAX) = '%polizasMigracion%'



SELECT DISTINCT
       o.name AS Object_Name
       --,o.type_desc
  FROM sys.sql_modules m with(nolock)
       INNER JOIN
       sys.objects o  with(nolock)
         ON m.object_id = o.object_id
WHERE [dbo].ReplaceAllSpaces(m.definition) LIKE @pSearchText

UNION

SELECT name
FROM   sys.procedures  with(nolock)
WHERE  [dbo].ReplaceAllSpaces(Object_definition(object_id)) LIKE @pSearchText

UNION

SELECT distinct object_name(id) 
FROM syscomments  with(nolock)
WHERE text like @pSearchText
--order by object_name(id)

UNION

SELECT distinct(SPECIFIC_NAME)
FROM INFORMATION_SCHEMA.ROUTINES   with(nolock)
WHERE [dbo].ReplaceAllSpaces(ROUTINE_DEFINITION) LIKE @pSearchText