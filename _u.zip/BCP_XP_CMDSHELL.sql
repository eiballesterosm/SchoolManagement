-----Inicio Generaci�n de archivo-----
DECLARE @nombreTabla AS VARCHAR(MAX) = 'tbl_reporte_gestion_cobro_85FBA1'
DECLARE @loginUsuario AS VARCHAR(100) = 'ballesterosed'
DECLARE @nombre_archivo VARCHAR(MAX)
DECLARE @comando_bcp VARCHAR(8000)
DECLARE @columnas_header VARCHAR(MAX)
DECLARE @columnas_registros VARCHAR(MAX)

--reporte_gestion_cobro_ballesterosed_2020_04_17T13_20_08.csv
SET @nombre_archivo = 'D:\CobranzaIn\Reporte_Mora\\reporte_gestion_cobro_' + @loginUsuario + '_' + REPLACE(REPLACE(CONVERT(CHAR(19), GETDATE(), 126), ':', '_'), '-', '_') + '.csv'

--header del archivo
SELECT @columnas_header = COALESCE(@columnas_header + ',', '') + '''' + column_name + ''''
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @nombreTabla

--registros
SELECT @columnas_registros = COALESCE(@columnas_registros + ',', '') + 'CAST(' + column_name + ' AS VARCHAR)'
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @nombreTabla

--Con autenticaci�n
--SET @comando_bcp = 'bcp "SELECT ' + @columnas_header + ' UNION ALL SELECT ' + @columnas_registros + ' FROM cobranza_P1.dbo.' + @nombreTabla + '" queryout "' + @nombre_archivo + '" -c -t ; -r \n -S BOGS005DVSQL16\DIGITALNORMALIZA -U svccobradig -P C0b4axw2019+'
SET @comando_bcp = 'bcp "SELECT ' + @columnas_header + ' UNION ALL SELECT ' + @columnas_registros + ' FROM cobranza_P.dbo.' + @nombreTabla + '" queryout "' + @nombre_archivo + '" -c -t ; -r \n -T'
print @comando_bcp

DECLARE @resultado_ejecucion AS INT = - 1;
EXEC @resultado_ejecucion = master..xp_cmdshell @comando_bcp

--Se elimina la tabla temporal
--EXEC ('DROP TABLE IF EXISTS ' + @nombreTabla)
-----Fin Generaci�n de archivo-----


select * from archivo_recaudo_externo order by 1 desc

--bcp "SELECT 'producto','convenio','producto_id','socio_producto_id','poliza_id','cliente_id','prima','asegurado','identificacion','tarjeta_id','numero_tarjeta_masc','numero_tarjeta','codigo_interno_tc','tipo_tarjeta','certificado','tipo_tarjeta_id','plan_cardif','canal','fecha_emision','fecha_inicio','fecha_fin','fecha_cancelacion','fecha_aplic_cancelacion','cancela_desc','cancela_codigo','vigencia_id','fecha_inicio_periodica','fecha_fin_periodica','altura','estado_vigencia_id','cobro_id','fecha_cobro','fecha_respuesta','fecha_envio_reversion','fecha_confirmacion_reversion','estado_vigencia','valor','valor_impuesto','valor_sin_impuesto','valor_reversion','porcentaje_reversion','ref_reversion','numero_aprobacion','estado_cobro','codigo_respuesta_id','respuesta_codigo','respuesta_descripcion','archivo_franquicia_id','lote','ident_cobro','ident_cobro2','nota','auxiliar_06','num_autorizacion','Periodo_de_amortizacion','Fecha_inicio_corte','Fecha_fin_corte','Indicador_unico_de_cobro' UNION ALL SELECT CAST(producto AS VARCHAR),CAST(convenio AS VARCHAR),CAST(producto_id AS VARCHAR),CAST(socio_producto_id AS VARCHAR),CAST(poliza_id AS VARCHAR),CAST(cliente_id AS VARCHAR),CAST(prima AS VARCHAR),CAST(asegurado AS VARCHAR),CAST(identificacion AS VARCHAR),CAST(tarjeta_id AS VARCHAR),CAST(numero_tarjeta_masc AS VARCHAR),CAST(numero_tarjeta AS VARCHAR),CAST(codigo_interno_tc AS VARCHAR),CAST(tipo_tarjeta AS VARCHAR),CAST(certificado AS VARCHAR),CAST(tipo_tarjeta_id AS VARCHAR),CAST(plan_cardif AS VARCHAR),CAST(canal AS VARCHAR),CAST(fecha_emision AS VARCHAR),CAST(fecha_inicio AS VARCHAR),CAST(fecha_fin AS VARCHAR),CAST(fecha_cancelacion AS VARCHAR),CAST(fecha_aplic_cancelacion AS VARCHAR),CAST(cancela_desc AS VARCHAR),CAST(cancela_codigo AS VARCHAR),CAST(vigencia_id AS VARCHAR),CAST(fecha_inicio_periodica AS VARCHAR),CAST(fecha_fin_periodica AS VARCHAR),CAST(altura AS VARCHAR),CAST(estado_vigencia_id AS VARCHAR),CAST(cobro_id AS VARCHAR),CAST(fecha_cobro AS VARCHAR),CAST(fecha_respuesta AS VARCHAR),CAST(fecha_envio_reversion AS VARCHAR),CAST(fecha_confirmacion_reversion AS VARCHAR),CAST(estado_vigencia AS VARCHAR),CAST(valor AS VARCHAR),CAST(valor_impuesto AS VARCHAR),CAST(valor_sin_impuesto AS VARCHAR),CAST(valor_reversion AS VARCHAR),CAST(porcentaje_reversion AS VARCHAR),CAST(ref_reversion AS VARCHAR),CAST(numero_aprobacion AS VARCHAR),CAST(estado_cobro AS VARCHAR),CAST(codigo_respuesta_id AS VARCHAR),CAST(respuesta_codigo AS VARCHAR),CAST(respuesta_descripcion AS VARCHAR),CAST(archivo_franquicia_id AS VARCHAR),CAST(lote AS VARCHAR),CAST(ident_cobro AS VARCHAR),CAST(ident_cobro2 AS VARCHAR),CAST(nota AS VARCHAR),CAST(auxiliar_06 AS VARCHAR),CAST(num_autorizacion AS VARCHAR),CAST(Periodo_de_amortizacion AS VARCHAR),CAST(Fecha_inicio_corte AS VARCHAR),CAST(Fecha_fin_corte AS VARCHAR),CAST(Indicador_unico_de_cobro AS VARCHAR) FROM cobranza_P.dbo.tbl_reporte_gestion_cobro_85FBA1" queryout "D:\CobranzaIn\reportes\gestion_cobro\reporte_gestion_cobro_ballesterosed_2020_07_29T12_52_39.csv" -c -t ; -r \n -T

--prueba b�sica de acceso 

exec xp_cmdshell 'dir D:\CobranzaIn\'
exec xp_cmdshell 'dir \\10.170.170.142'
exec xp_cmdshell 'dir D:\ssis\*.*'
exec xp_cmdshell 'dir D:\CobranzaIn\Prueba\*.*'
exec xp_cmdshell 'dir D:\carguesocios\*.*'
exec xp_cmdshell 'dir D:\carguesocios\sac\csv\*.*'
exec xp_cmdshell 'dir  \\BOGS007TESIIS\Archivos'
exec xp_cmdshell 'pushd  \\10.170.170.134\Archivos'
exec xp_cmdshell 'dir \\10.170.170.134\Cobro'
exec xp_cmdshell 'pushd  \\BOGS007QAIISN1\websites\Cobra'
exec xp_cmdshell 'pushd  \\BOGS007QAIISN1\Archivos //D'
exec xp_cmdshell 'dir  \\BOGS007QAIISN1\Archivos\ /D'
exec xp_cmdshell 'dir  \\BOGS007QAIISN1\Archivos'
exec xp_cmdshell 'copy \\BOGS007QAIISN1\Archivos\465CO65CS2021111700.txt D:\CobranzaIn\Prueba\211CO96RS1002021100700.txt'
exec xp_cmdshell 'dir D:\'
exec xp_cmdshell 'dir  \\10.170.170.134\websites'

exec xp_cmdshell 'dir D:\CobranzaIn\arc_pqr'

cobranza_p_backup_2021_10_19_210003_2485858.bak

exec xp_cmdshell 'copy O:\backup\cobranza\backup\full\cobranza_p_backup_2021_10_19_210003_2485858.bak D:\ssis\cobranza_p_backup_2021_10_19_210003_2485858.bak'

exec xp_cmdshell 'del D:\ssis\cobranza_p_backup_2021_10_19_210003_2485858.bak'

exec xp_cmdshell 'dir D:\CobranzaIn\'

exec xp_cmdshell 'copy D:\ssis\VI_1222_20211022-135912_004_00.txt  D:\CobranzaIn\arc_franquicias\VI_1222_20211022-135912_004_00.txt'
exec xp_cmdshell 'dir D:\ssis\VI_738_20211022-134332_007_00.txt'


exec xp_cmdshell 'copy D:\CobranzaIn\arc_pqr\20211014082534-Nov6871-8.txt D:\ssis\20211014082534-Nov6871-8.txt'


exec xp_cmdshell 'dir D:\CobranzaIn\arc_externos\'
exec xp_cmdshell 'copy D:\CobranzaIn\arc_externos\ex_20211025074806-d43167_falabella_post_migracion_0040.txt D:\ssis\ex_20211025074806-d43167_falabella_post_migracion_0040.txt'
exec xp_cmdshell 'dir D:\CobranzaIn\arc_externos\ex_20211013114353-Recaudo Anual 3.txt'

20211013060814-Nov6871-21.txt
20211014082534-Nov6871-8.txt
20210930075951-Nov6871-1.txt

exec xp_cmdshell 'copy D:\CobranzaIn\arc_pqr\20211013060814-Nov6871-21.txt D:\ssis\20211013060814-Nov6871-21.txt'
exec xp_cmdshell 'copy D:\CobranzaIn\arc_pqr\20211014082534-Nov6871-8.txt D:\ssis\20211014082534-Nov6871-8.txt'
exec xp_cmdshell 'copy D:\CobranzaIn\arc_pqr\20210930075951-Nov6871-1.txt D:\ssis\20210930075951-Nov6871-1.txt'

exec xp_cmdshell 'dir \\BOGS007QAIISN1\websites\Cobra\arc_franquicias\Archivos'
exec xp_cmdshell 'dir \\BOGS007QAIISN1\websites\Cobra\arc_franquicias\Archivos'
exec xp_cmdshell 'dir \\BOGS007QAIISN1\Archivos'
exec xp_cmdshell 'dir \\BOGS007TESIIS\websites\Cobra'

exec xp_cmdshell 'dir \\BOGS007TESIIS\websites'

exec xp_cmdshell 'copy \\BOGS007TESIIS\websites\Cobra\VI_083CO11CS2118122002021101400.txt D:\CobranzaIn\credibanco\VI_083CO11CS2118122002021101400.txt'

exec xp_cmdshell 'copy \\BOGS007TESIIS\websites\Cobra\VI_083CO11CS2118122002021101400.txt D:\CobranzaIn\credibanco\VI_083CO11CS2118122002021101400.txt'

exec xp_cmdshell 'copy \\BOGS007QAIISN1\websites\Cobra\arc_franquicias\Archivos\465CO65CS2021112300.txt D:\CobranzaIn\Prueba\465CO65CS2021112300.txt'

exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /grant Everyone:F /t'
exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /grant "everyone":F'
exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /setowner  "d43167"'
exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /remove "d43167"'
exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /remove "everyone"'
exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /inheritance:r'
exec xp_cmdshell 'iCACLS \\BOGS007QAIISN1\websites\Cobra\11012018Web.config /T /Q /C /RESET'


exec xp_cmdshell 'pushd  \\BOGS007QAIISN1\websites\Cobra'
exec xp_cmdshell 'dir  \\BOGS007QAIISN1\websites\Cobra'
exec xp_cmdshell 'copy \\BOGS007QAIISN1\websites\Cobra\bin\cobra_api.pdb \\BOGS007QAIISN1\websites\Cobra\bin\cobra_api_1.pdb'

exec xp_cmdshell 'copy D:\cobranzain\arc_conf\responseFalabellaPeruPostMigracionCuerpo-f-c.fmt D:\ssis\responseFalabellaPeruPostMigracionCuerpo-f-c.fmt'

exec xp_cmdshell 'copy D:\ssis\layouts\arc_conf D:\cobranzain\arc_conf'

declare @archivo as varchar(100) = 'responseFalabellaPeruPostMigracionCuerpo-f-c.fmt'
exec xp_cmdshell concat('copy D:\cobranzain\arc_conf\', @archivo, 'D:\ssis\layouts'@archivo)


select * from archivo_recaudo_externo order by archivo_recaudo_externo_id desc

exec xp_cmdshell 'copy D:\Cobranzain\arc_externos\ex_20211023020116-d43167_falabella_post_migracion_0038.txt D:\ssis\ex_20211023020116-d43167_falabella_post_migracion_0038.txt'

exec xp_cmdshell 'del D:\ssis\VI_738_20211022-134332_007_00.txt'


exec xp_cmdshell 'dir D:\Cobranzain\arc_externos\ \D'

select * from DBA_Auditlog
where UserName = 'debug'
order by TrxDate desc



ex_20211012121302-AgrarioTercero1840-6 ok2.txt

exec xp_cmdshell 'dir D:\cobranzain\arc_conf'
exec xp_cmdshell 'dir D:\cobranzain\'

exec xp_cmdshell 'dir \\BOGS007QAIISN1'
exec xp_cmdshell 'dir  \\BOGS007TESIIS\Archivos'
exec xp_cmdshell 'dir  \\10.170.170.134\Archivos'
exec xp_cmdshell 'copy D:\ssis\VI_750_20210201-182059_007_00.txt \\10.170.170.134\Archivos\'
exec xp_cmdshell 'del \\10.170.170.134\Archivos\VI_750_20210201-182059_007_00.txt'

\\10.170.170.142\ssis\layouts


exec xp_cmdshell 'copy D:\ssis\20210127053202-RESPUESTA_VI_750_20210127-135820_007_00.txt D:\cobranzain\arc_respuestas\'
exec xp_cmdshell 'copy D:\ssis\Create_bind_01301978100025007_27012021214147.dat D:\cobranzain\credibanco\20210127_135626_Create_bind_01301978100025007_27012021214147.dat'
exec xp_cmdshell 'copy D:\ssis\responseCATPeruCuerpo-f-c.fmt D:\cobranzain\arc_conf\'
exec xp_cmdshell 'copy D:\ssis\responseVisaCredibancoCuerpo-f-c.fmt D:\cobranzain\arc_conf\'
exec xp_cmdshell 'copy D:\ssis\cobranzain\arc_externos\ex_20210118035555-MARRecaudo72-180120212RespuestaTEST_d43167_9.txt D:\cobranzain\arc_externos\'

exec xp_cmdshell 'copy D:\cobranzain\arc_externos\ex_20210805033736-615LPR8601RR210791.txt D:\ssis\'
exec xp_cmdshell 'copy D:\cobranzain\arc_pqr\20210930075951-Nov6871-1.txt D:\ssis\'

exec xp_cmdshell 'copy D:\cobranzain\arc_pqr\20210922050345-20210922_alkosto_0001.txt D:\ssis\'
exec xp_cmdshell 'copy D:\cobranzain\arc_pqr\20210924084600-cancelacion_popular_1.txt D:\ssis\'


exec xp_cmdshell 'copy D:\cobranzain\arc_externos\ex_20210405071431-Recaudo_codensa_25_de_Marzo_2021.txt D:\ssis\'


exec xp_cmdshell 'copy D:\CobranzaIn\reporte_mora\mora_canc_20211011_1_1A5.csv D:\ssis\mora_canc_20211011_1_1A5.cs'

exec xp_cmdshell 'dir D:\CobranzaIn\reportes'


    


exec xp_cmdshell 'dir D:\cobranzain\arc_externos\'


exec xp_cmdshell 'dir D:\ssis\*.*'
exec xp_cmdshell 'dir D:\cobranzain\*.*'
exec xp_cmdshell 'dir D:\cobranzain\'
exec xp_cmdshell 'dir D:\cobranzain\credibanco'
exec xp_cmdshell 'dir D:\cobranzain\arc_respuestas'
exec xp_cmdshell 'dir D:\cobranzain\reportes\'
exec xp_cmdshell 'dir D:\cobranzain\*.*'
exec xp_cmdshell 'dir D:\cobranzain\arc_conf\*.*'
exec xp_cmdshell 'dir D:\cobranzain\arc_externos\*.*'
exec xp_cmdshell 'dir D:\cobranzain\reportes\*6721.*'
--exec xp_cmdshell 'rmdir /s /q D:\cobranzain\reporte_mora'
exec xp_cmdshell 'mkdir D:\cobranzain\arc_conf'
exec xp_cmdshell 'mkdir D:\cobranzain\reporte_mora'
exec xp_cmdshell 'mkdir D:\cobranzain\credibanco'
exec xp_cmdshell 'mkdir D:\cobranzain\reportes\gestion_cobro'
exec xp_cmdshell 'copy D:\cobranzain\arc_externos\ex_20210202122401-Falabellarecaudo-4.txt D:\ssis\'
exec xp_cmdshell 'copy D:\cobranzain\arc_conf\responseCATPeruNuevas7202_03_04Cuerpo-f-c.fmt D:\ssis\'
exec xp_cmdshell 'rmdir D:\cobranzain\Prueba'
exec xp_cmdshell 'dir D:\cobranzain\reportes\'
exec xp_cmdshell 'dir D:\cobranzain\arc_conf\'
exec xp_cmdshell 'del D:\cobranzain\reportes\gestion_vigencia\reporte_gestion_vigencia_quinterojo_2020_04_29T09_01_02.csv'
exec xp_cmdshell 'del D:\cobranzain\arc_conf\responseCATPeruNuevas2Cuerpo-f-c.fmt'

exec xp_cmdshell 'del D:\ssis\20210922050345-20210922_alkosto_0001.txt'



exec xp_cmdshell 'copy D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt D:\cobranzain\arc_conf\responseCATPeruCuerpo-f-c.fmt'
--exec xp_cmdshell 'del D:\cobranzain\arc_conf\tt.txt'

exec xp_cmdshell 'CACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /e /p "Eduardo BALLESTEROS (Eduardo.BALLESTEROS@CRDF.bnpparibas.com)":F'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\ /grant Everyone:F /t'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /grant $domain\$user'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /grant "everyone":F'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /setowner  "d43167"'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /remove "d43167"'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /remove "everyone"'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /inheritance:r'
exec xp_cmdshell 'iCACLS D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt /T /Q /C /RESET'








exec xp_cmdshell 'dir D:\cobranzain\reporte_mora\'

select * from reporte_seguimiento_mora

exec xp_cmdshell 'type D:\cobranzain\Reporte_Mora\mora_canc_20200812_1_02B.csv'
--crea un archivo vac�o
exec xp_cmdshell 'echo. > D:\cobranzain\Reporte_Mora\sin_datos.csv'

--contenido archivos
SELECT * FROM OPENROWSET(BULK N'D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt', SINGLE_CLOB) AS Contents


------INICIO CREAR FMT-----------
drop table if exists archivos
CREATE TABLE [dbo].archivos(
	[contenido] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

DECLARE @path_archivo VARCHAR(2000)
DECLARE @comando_bcp VARCHAR(8000)
--SET @path_archivo = 'D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt'
--SET @path_archivo = 'D:\cobranzain\arc_conf\responseCATPeruNuevas7202_03_04Cuerpo-f-c.fmt'
--SET @path_archivo = 'D:\cobranzain\arc_respuestas\20210630112249-20210630_OCCIDENTE_REPRECOBRO_083CO11CS211106300_004.txt'
--SET @path_archivo = 'D:\cobranzain\arc_conf\responseCATPeruNuevas979Cuerpo-f-c.fmt'
--SET @path_archivo = 'D:\cobranzain\arc_conf\responsePreCobroAvVillasCuerpo-f-c.fmt'
SET @path_archivo = 'D:\cobranzain\arc_externos\ex_20211231023658-548CO25RR1722105221_total.txt'
--SET @path_archivo = 'D:\cobranzain\arc_franquicias\SCOTIABANK_COBRO_2021102800.txt'
--SET @path_archivo = 'D:\cobranzain\arc_franquicias\MC_083CO11CS2118122002021102000.txt'
--SET @path_archivo = 'D:\cobranzain\arc_pqr\20210823012623-20210823_alkosto_0001.txt'
SET @comando_bcp = 'bcp "SELECT * FROM cobranza_P.dbo.archivos " queryout "' + @path_archivo + '" -c -t ; -r \n -T'
DECLARE @resultado_ejecucion AS INT = - 1;
EXEC @resultado_ejecucion = master..xp_cmdshell @comando_bcp
------FIN CREAR FMT-----------

exec xp_cmdshell 'del D:\cobranzain\arc_conf\txt'
exec xp_cmdshell 'del D:\cobranzain\arc_conf\responseScotiabankPeruMigracionCuerpo-f-c.fmt'
exec xp_cmdshell 'del D:\cobranzain\arc_conf\responseCATPeruCuerpo-f-c.fmt'

declare @texto as varchar(5000)
select @texto = test from test
exec spWriteStringToFile @texto,'D:\cobranzain\arc_conf\' ,'responseCATPeruCuerpo-f-c.fmt'



exec xp_cmdshell 'dir D:\CobranzaIn\arc_conf'
exec xp_cmdshell 'copy D:\cobranzain\arc_conf\responseFalabellaPeruPostMigracionCuerpo-f-c.fmt D:\CierreContable\responseFalabellaPeruPostMigracionCuerpo-f-c.fmt'



--Inicio leer archivo
set nocount on

create table #file_contents (
 line_number int identity,
 line_contents nvarchar(4000)
)

declare @file_contents nvarchar(4000)
declare @new_line char(2)

set @new_line = char(13) + char(10)

insert #file_contents
exec master.dbo.xp_cmdshell 'type "D:\CobranzaIn\arc_externos\ex_20211221031401-preprod_d43167_cat_nuevas_7201_0001.txt"'
--exec master.dbo.xp_cmdshell 'type "D:\CobranzaIn\arc_externos\ex_20211219095939-falabella_post_20211219_001.txt"'
--exec master.dbo.xp_cmdshell 'type "D:\cobranzain\arc_conf\responseFalabellaPeruPostMigracionCuerpo-f-c.fmt"'

select @file_contents =
 isnull(@file_contents, '') + @new_line +
 isnull(line_contents, '')
from #file_contents

drop table #file_contents

select @file_contents

set nocount off
--Fin leer archivo