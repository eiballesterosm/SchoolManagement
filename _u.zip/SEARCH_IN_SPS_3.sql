DECLARE @SearchPattern NVARCHAR(128)

SET @SearchPattern = '%establecimiento%'

SELECT SCHEMA_NAME(o.schema_id) as [schema]
,      o.[name]
,      o.[type]
,      '['+SCHEMA_NAME(o.schema_id)+'].['+o.[name]+']' as FullName
,      OBJECT_DEFINITION(object_id) AS [Source]
FROM sys.objects AS o
WHERE lower(OBJECT_DEFINITION(o.object_id)) LIKE lower(@SearchPattern)
    AND o.[type] IN (
    'C',--- = Check constraint
    'D',--- = Default (constraint or stand-alone)
    'P',--- = SQL stored procedure
    'FN',--- = SQL scalar function
    'R',--- = Rule
    'RF',--- = Replication filter procedure
    'TR',--- = SQL trigger (schema-scoped DML trigger, or DDL trigger at either the database or server scope)
    'IF',--- = SQL inline table-valued function
    'TF',--- = SQL table-valued function
    'V') --- = View
ORDER BY o.[type]
,        o.[name]