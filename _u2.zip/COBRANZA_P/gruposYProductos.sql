SELECT
	g.grupo_id
	,g.descripcion
	,(SELECT STUFF((
				SELECT distinct ', ''' + p.codigo_core +''''
				FROM grupo 
					INNER JOIN socio_producto sp ON grupo.grupo_id = sp.grupo_id 
					INNER JOIN producto p on p.producto_id = sp.producto_id and grupo.grupo_id = g.grupo_id FOR XML PATH ('')),1,2,'')) productosPims
	,(SELECT STUFF((
				SELECT distinct ', ''' + p.codigo +''''
				FROM grupo 
					INNER JOIN socio_producto sp ON grupo.grupo_id = sp.grupo_id 
					INNER JOIN producto p on p.producto_id = sp.producto_id and grupo.grupo_id = g.grupo_id FOR XML PATH ('')),1,2,'')) productosCobra
	,replace(
		replace(g.informacion
			,'%s1'
			,'('+(SELECT STUFF((
				SELECT distinct ', ' + p.codigo_core 
				FROM grupo 
					INNER JOIN socio_producto sp ON grupo.grupo_id = sp.grupo_id 
					INNER JOIN producto p on p.producto_id = sp.producto_id and grupo.grupo_id = g.grupo_id FOR XML PATH ('')),1,2,''))+')'
		)
		,'%s2'
		,'('+(SELECT STUFF((
			SELECT distinct ', ' + p.codigo_core
����������� FROM grupo
	����������� INNER JOIN socio_producto sp ON grupo.grupo_id = sp.grupo_id
				INNER JOIN producto p on p.producto_id = sp.producto_id and grupo.grupo_id = g.grupo_id FOR XML PATH ('')),1,2, ''))+')'
	) query--+' and PDCO.AUDITDATE between TRUNC(sysdate)  AND TRUNC(SYSDATE) +1' query
FROM�
	grupo g
	where g.tipo_grupo_id = 1
	and g.grupo_id IN (90,91,92)
	and g.descripcion like '%SCSUS080 - Emisiones%'