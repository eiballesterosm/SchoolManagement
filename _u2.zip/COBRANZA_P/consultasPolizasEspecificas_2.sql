DECLARE @pPolizaID AS VARCHAR(MAX) = '193846'
DECLARE @pNumeroPoliza AS VARCHAR(MAX) = ''

IF LEN(@pPolizaID) < 1
	AND LEN(@pNumeroPoliza) < 1
BEGIN
	PRINT 'INGRESE LOS VALORES PARA poliza_id o numero_poliza'
END

IF (LEN(@pPolizaID) < 1)
BEGIN
	SELECT TOP 1 @pPolizaID = poliza_id
	FROM poliza
	WHERE numero_poliza = @pNumeroPoliza
END
ELSE
BEGIN
	PRINT 'NO se encontraron n�mero de p�lizas v�lidos'
END

SELECT *
FROM archivo_pqr
WHERE archivo_pqr_id IN (
		SELECT archivo_pqr_id
		FROM poliza
		WHERE poliza_id = @pPolizaID
		)

--Poliza
SELECT activa,
	amortizacion,
	*
FROM poliza PO
WHERE poliza_id = @pPolizaID

--Cliente
SELECT *
FROM cliente
WHERE cliente_id IN (
		SELECT cliente_id
		FROM poliza PO
		WHERE poliza_id = @pPolizaID
		)

--Producto
SELECT sp.prima,
	soc.descripcion,
	pr.*,
	sp.*
FROM poliza po
JOIN socio_producto sp ON sp.socio_producto_id = po.socio_producto_id
JOIN producto pr ON pr.producto_id = sp.producto_id
JOIN socio soc ON soc.socio_id = sp.socio_id
WHERE poliza_id = @pPolizaID

--Vigencias
SELECT 'VIGENCIAS',
	vigencia.poliza_id,
	vigencia_id,
	vigencia.numero,
	estado_vigencia.descripcion ESTADO,
	estado_vigencia.es_recaudo,
	*
FROM vigencia WITH (NOLOCK)
INNER JOIN estado_vigencia ON estado_vigencia.estado_vigencia_id = vigencia.estado_vigencia_id
WHERE poliza_id = @pPolizaID
ORDER BY vigencia.poliza_id,
	vigencia.numero

--Cobros
SELECT 'COBROS',
	cobro.tarjeta_id,
	cobro.tarjeta_cascada_id,
	vigencia.poliza_id,
	cobro_id,
	vigencia.vigencia_id,
	vigencia.numero,
	estado_vigencia.descripcion ESTADO,
	estado_vigencia.es_recaudo,
	codigo_respuesta.descripcion CODIGO_RESPUESTA,
	*
FROM cobro WITH (NOLOCK)
INNER JOIN estado_vigencia ON estado_vigencia.estado_vigencia_id = cobro.estado_vigencia_id
INNER JOIN vigencia WITH (NOLOCK) ON vigencia.vigencia_id = cobro.vigencia_id
LEFT JOIN codigo_respuesta ON codigo_respuesta.codigo_respuesta_id = cobro.codigo_respuesta_id
WHERE poliza_id = @pPolizaID
ORDER BY vigencia.poliza_id,
	vigencia.numero,
	cobro.cobro_id

--SELECT * FROM archivo_novedad_detalle WHERE poliza_id = (SELECT poliza_id from poliza WHERE numero_poliza = @pNumeroPoliza)
--SELECT IIF(archivo_pqr.fecha <> '1900-01-01',CONVERT(VARCHAR(10),archivo_pqr.fecha),SUBSTRING(archivo_pqr.nombre, 1, 8)), * FROM archivo_pqr WHERE archivo_pqr_id = (SELECT archivo_pqr_id from poliza WHERE numero_poliza = @pNumeroPoliza)
SELECT tipo_tarjeta.descripcion,
	tipo_tarjeta.es_tc,
	tarjeta.*
FROM tarjeta
JOIN poliza ON poliza.tarjeta_id = tarjeta.tarjeta_id
JOIN tipo_tarjeta ON tipo_tarjeta.tipo_tarjeta_id = tarjeta.tipo_tarjeta_id
WHERE poliza_id IN (
		SELECT poliza_id
		FROM poliza PO
		WHERE PO.poliza_id = @pPolizaID
		)

SELECT tipo_tarjeta.descripcion,
	tipo_tarjeta.es_tc,
	*
FROM tarjeta
JOIN tipo_tarjeta ON tipo_tarjeta.tipo_tarjeta_id = tarjeta.tipo_tarjeta_id
WHERE cliente_id IN (
		SELECT cliente_id
		FROM poliza PO
		WHERE PO.poliza_id = @pPolizaID
		)
