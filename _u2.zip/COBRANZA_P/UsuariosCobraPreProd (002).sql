USE [cobranza_P]
GO
DELETE from [dbo].[usuario] where login in ( 'villamilca','morenoja2','rabeloje', 'd35274', 'd03555', 'd56206', 'd39250', 'ballesterosed', 'd39957' )
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Carol Villamil','villamilca','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Jaime Moreno','morenoja2','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Jenny Rabelo','rabeloje','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Luis Esteban Vargas','d35274','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Carlos Gaona','d03555','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Yeiner Meri�o','d56206','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Jonathan Aponte','d39250','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Eduardo Ballesteros','ballesterosed','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Andres Felipe Quintana','d39957','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
select * from [dbo].[usuario]
where login in ( 'villamilca','morenoja2','rabeloje', 'd35274', 'd03555', 'd56206', 'd39250', 'ballesterosed', 'd39957', 'quinterojo' )
