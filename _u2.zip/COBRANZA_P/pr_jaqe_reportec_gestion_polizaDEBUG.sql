--EJECUCIÓN DE SP
--USE [cobranza_P]
--GO

--DECLARE	@return_value int

--EXEC	@return_value = [dbo].[pr_jaqe_reportec_gestion_poliza]
--		@productos = '',
--		@sIdentificacion = '',
--		@estado_vigencia = '',
--		@mediosDePago = '',
--		@sCodigo_interno = '',
--		@sNumero_poliza = N'''75710655909096590''',
--		@dias_mora = N'61',
--		@fecha_mora = N'20200619',
--		@estado_poliza = 2,
--		@tipo_fecha = 0,
--		@fecha1 = N'0',
--		@fecha2 = N'0'

--SELECT	'Return Value' = @return_value

--GO



USE [cobranza_P]
GO

	DECLARE @productos varchar(500) = ''
	DECLARE @sIdentificacion varchar(MAX) = ''
	--DECLARE @sNumero_poliza varchar(MAX) = N'''75710655909096590'''
	DECLARE @sNumero_poliza varchar(MAX) = N'''75710655909096590'''
	DECLARE @estado_vigencia varchar(50) = ''
	DECLARE @dias_mora varchar(10) = '61'
	DECLARE @fecha_mora varchar(10) = (select convert(varchar, getdate(), 112))
	DECLARE @estado_poliza int = 2
	DECLARE @mediosDePago varchar(MAX) = ''
	DECLARE @tipo_fecha int = '1'
	DECLARE @fecha1 varchar(10) = '20200207'
	DECLARE @fecha2 varchar(10) = '20200207'
	DECLARE @sCodigo_interno varchar(MAX) = ''


SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON

declare @sql varchar(MAX)
declare @sql_fechas varchar(MAX)
declare @ahora varchar(20)
declare @ahora_m varchar(20)
declare @ahora_y varchar(20)

set @ahora = convert(varchar(8),getdate(),112) + ' ' + convert(varchar(8),getdate(),108)
set @ahora_m = cast(month(getdate()) as varchar(5))
set @ahora_y = cast(year(getdate()) as varchar(5))

set @sql = ''

if @productos is not null and @productos <> ''
	set @sql = @sql + ' and producto.codigo in ( '+  @productos + ' )'
	
if @sIdentificacion is not null and @sIdentificacion <> ''
	set @sql = @sql + ' and cliente.identificacion in ('+ @sIdentificacion + ' )'
	
if @sNumero_poliza is not null and @sNumero_poliza <> ''
	set @sql = @sql + ' and poliza.numero_poliza in ('+ @sNumero_poliza + ' )'
	
if @estado_vigencia is not null and @estado_vigencia <> ''
	set @sql = @sql + ' and cobro.estado_vigencia_id in ('+ @estado_vigencia + ' )'
	
if @dias_mora is not null and @dias_mora <> '' and @dias_mora <> '0'
	--set @sql = @sql + ' and datediff(day, min_vigencia_no_recaudada.fecha_ini, ''' + @fecha_mora + ''') >= ' + @dias_mora
	set @sql = @sql + ' and IIF(datediff(day, ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), ''' + @fecha_mora + ''' ) IS NULL OR datediff(day, ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), ''' + @fecha_mora + ''' ) < 0, 0, datediff(day, ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), ''' + @fecha_mora + ''' )) >= ' + @dias_mora
	
	
if (@estado_poliza is not null) and (@estado_poliza = 2)
	set @sql = @sql + ' and poliza.fecha_cancelacion is null '
if (@estado_poliza is not null) and (@estado_poliza = 3)
	set @sql = @sql + ' and poliza.fecha_cancelacion is not null '
	
if @mediosDePago is not null and @mediosDePago <> ''
	set @sql = @sql + ' and tarjeta.numero in ( '+ @mediosDePago + ' )'

set @sql_fechas = (select [dbo].[fnc_reporte_filtro_fecha] (@tipo_fecha, @fecha1, @fecha2))

	--JHIGUERA COAASDK-14386 Visualización en cobra canal de venta Producto cáncer
	--Fecha: 22/11/2016
declare @script as varchar(max) =
' 
select 
	producto.codigo as producto, 
	socio_producto.prima, 
	cliente.nombre as asegurado, 
	cliente.identificacion, 
	numero_tarjeta_masc = CASE len(dbo.tarjeta.numero) 
	   WHEN 15 THEN substring(tarjeta.numero, 1, 6) + ''******'' + substring(tarjeta.numero, len(tarjeta.numero)-3, 4) 
	   WHEN 16 THEN substring(tarjeta.numero, 1, 6) + ''******'' + substring(tarjeta.numero, len(tarjeta.numero)-3, 4) 
	   ELSE ''*****'' + substring(dbo.tarjeta.numero, len(dbo.tarjeta.numero)-3, 4) 
	END, 
	tarjeta.numero as numero_tarjeta,  
	tarjeta.codigo_interno as codigo_interno_tc,  
	tipo_tarjeta.descripcion as tipo_tarjeta, 
	poliza.poliza_id,
	poliza.activa,
	poliza.numero_poliza as certificado, 
	poliza.llave_homologada, 
	CONVERT(VARCHAR(8), poliza.fecha_emision, 112) AS fecha_emision, 
	CONVERT(VARCHAR(8), poliza.fecha_inicio, 112) AS fecha_inicio, 
	CONVERT(VARCHAR(8), poliza.fecha_fin, 112) AS fecha_fin, 
	CONVERT(VARCHAR(8), archivo_produccion.fecha_cargue, 112) AS fecha_cobra, 
	plancardif.codigo as planx, 
	CONVERT(VARCHAR(8), poliza.fecha_cancelacion, 112) AS fecha_cancelacion, 
	datediff(day,poliza.fecha_inicio,poliza.fecha_cancelacion) as dias_permanencia,
	CONVERT(VARCHAR(8), archivo_pqr.fecha, 112) AS fecha_aplic_cancelacion,  
	usuario.login as usuario_cancelo, 
	poliza.motivo_cancelacion, 
	tipo_cancelacion.descripcion as cancela_desc,
	tipo_cancelacion.codigo as cancela_codigo,
	replace(replace(CONVERT (varchar(17), CAST(poliza.valor_prima AS money), 1),'','',''''),''.'','','') as valor_prima, 
	replace(replace(CONVERT (varchar(17), CAST(poliza.valor_sin_impuesto AS money), 1),'','',''''),''.'','','') as valor_sin_impuesto, 
	replace(replace(CONVERT (varchar(17), CAST(poliza.valor_impuesto AS money), 1),'','',''''),''.'','','') as valor_impuesto,
	--[dbo].[fnc_altura](poliza.fecha_inicio,''' + @ahora + ''',isnull(poliza.amortizacion, socio_producto.prima)) as altura_actual,
	ISNULL((SELECT TOP 1 numero FROM vigencia WHERE poliza_id = poliza.poliza_id AND ''' + @ahora + ''' BETWEEN fecha and fecha_fin), (SELECT MAX(numero) FROM vigencia WHERE poliza_id = poliza.poliza_id)) as altura_actual,
	count(cobro.cobro_id) as total_cobros, 
	count(cobro_efectivos.cobro_id) as efectivos, 
	count(cobro_promo.vigencia_id) as promos, 
	count(cobro_rechazados.cobro_id) as rechazados, 
	count(cobro_pendientes.cobro_id) as pendiente_respuesta, 
	count(cobro_revertidos.cobro_id) as revertidos, 
	count(cobro_precobrados.cobro_id) as precobrados, 
	count(cobro_precob_aprob.cobro_id) as precobrados_si, 
	count(cobro_precob_recha.cobro_id) as precobrados_no, 
	count(cobro_errados.cobro_id) as errores, 	
	(SELECT count(cobro.cobro_id) AS cantidad_cobros
				FROM cobro WITH (NOLOCK)
				INNER JOIN vigencia VI WITH (NOLOCK) ON cobro.vigencia_id = VI.vigencia_id AND VI.poliza_id = poliza.poliza_id
					AND VI.numero > (
						(
							max_vigencia_recaudada.altura
						)
				)				
				WHERE cobro.estado_vigencia_id IN (
						SELECT estado_vigencia_id
						FROM estado_vigencia
						WHERE descripcion LIKE ''PRECOBRADA RECHAZADA''
							OR descripcion LIKE ''RECHAZADA''
						)) as cobros_post_recaudo, 
	cobros_mes.cobros_efectivos_mes,
	ISNULL((SELECT TOP 1 numero FROM vigencia WHERE poliza_id = poliza.poliza_id AND ''' + @ahora + ''' BETWEEN fecha and fecha_fin), (SELECT MAX(numero) FROM vigencia WHERE poliza_id = poliza.poliza_id)) - ((count(cobro_promo.vigencia_id) + count(cobro_efectivos.cobro_id))) AS pendientes_recaudo,
	replace(replace(CONVERT (varchar(17), CAST(
													--([dbo].[fnc_altura](poliza.fecha_inicio,''' + @ahora + ''',socio_producto.prima) - count(cobro_efectivos.cobro_id)) * poliza.valor_prima 
													(ISNULL((SELECT TOP 1 numero FROM vigencia WHERE poliza_id = poliza.poliza_id AND ''' + @ahora + ''' BETWEEN fecha and fecha_fin), (SELECT MAX(numero) FROM vigencia WHERE poliza_id = poliza.poliza_id)) - count(cobro_efectivos.cobro_id)) * poliza.valor_prima 
												AS money), 1),'','',''''),''.'','','') as cartera_pendiente, 
	CONVERT(VARCHAR(8), ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), 112) as menor_inicio_no_recaudada,
	IIF(datediff(day, ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), ''' + @fecha_mora + ''' ) IS NULL OR datediff(day, ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), ''' + @fecha_mora + ''' ) < 0, 0, datediff(day, ISNULL(min_vigencia_no_recaudada.fecha_ini, poliza.fecha_inicio), ''' + @fecha_mora + ''' )) as dias_mora,
	--datediff(day, min_vigencia_no_recaudada.fecha_ini, ''' + @fecha_mora + ''' ) as dias_mora, 
	CONVERT(VARCHAR(8), max_vigencia_recaudada.fecha_fin, 112) as fecha_cobertura, 
	min(CONVERT(VARCHAR(8), cobro.fecha_cobro, 112)) as primer_cobro, 
	max(CONVERT(VARCHAR(8), cobro.fecha_cobro, 112)) as ultimo_cobro, 
	min(CONVERT(VARCHAR(8), cobro_efectivos.fecha_respuesta, 112)) as primer_recaudo, 
	max(CONVERT(VARCHAR(8), cobro_efectivos.fecha_respuesta, 112)) as ultimo_recaudo, 
	ultimo_rechazo.cobro_id, 
	respuesta.descripcion as ultimo_rechazo,
	poliza.nota,
	poliza.origen_venta,
	poliza.codigo_asesor,
	ISNULL(poliza.amortizacion, socio_producto.prima) AS Periodo_de_amortizacion,
	poliza.fecha_corte_inicio AS Fecha_inicio_corte,
	poliza.fecha_corte_fin AS Fecha_fin_corte	'

declare @script1 AS VARCHAR(MAX) = 
'from poliza with (nolock)
	inner join archivo_produccion with (nolock) on (archivo_produccion.archivo_produccion_id = poliza.archivo_produccion_id) 
	inner join cliente with (nolock) on (poliza.cliente_id = cliente.cliente_id) 
	inner join tarjeta with (nolock) on (poliza.tarjeta_id = tarjeta.tarjeta_id) 
	inner join socio_producto with (nolock) on (socio_producto.socio_producto_id = poliza.socio_producto_id) 
	inner join producto with (nolock) on (producto.producto_id = socio_producto.producto_id) 
	inner join plancardif with (nolock) on (poliza.plancardif_id = plancardif.plancardif_id) 
	inner join tipo_tarjeta with (nolock) on (tipo_tarjeta.tipo_tarjeta_id = tarjeta.tipo_tarjeta_id) 
	inner join vigencia with (nolock) on (vigencia.poliza_id = poliza.poliza_id) 
	left join tipo_cancelacion with (nolock) on tipo_cancelacion.tipo_cancelacion_id = poliza.tipo_cancelacion_id
	left join cobro with (nolock) on (cobro.vigencia_id = vigencia.vigencia_id) 
	left join cobro as cobro_efectivos with (nolock) on  (cobro_efectivos.cobro_id = cobro.cobro_id
											and cobro_efectivos.estado_vigencia_id in (4,12,14,15,16))
	left join cobro as cobro_rechazados with (nolock) on (cobro_rechazados.cobro_id = cobro.cobro_id
											and cobro_rechazados.estado_vigencia_id = 3)
	left join cobro as cobro_pendientes with (nolock) on (cobro_pendientes.cobro_id = cobro.cobro_id
											and cobro_pendientes.estado_vigencia_id = 2) 
	left join cobro as cobro_precobrados with (nolock) on (cobro_precobrados.cobro_id = cobro.cobro_id 
											 and cobro_precobrados.estado_vigencia_id = 9) 
	left join cobro as cobro_precob_aprob with (nolock) on (cobro_precob_aprob.cobro_id = cobro.cobro_id 
											 and cobro_precob_aprob.estado_vigencia_id = 11) 
	left join cobro as cobro_precob_recha with (nolock) on (cobro_precob_recha.cobro_id = cobro.cobro_id 
											 and cobro_precob_recha.estado_vigencia_id = 10) 
	left join vigencia as cobro_promo with (nolock) on (cobro_promo.vigencia_id = vigencia.vigencia_id
											 and cobro_promo.estado_vigencia_id = 6) 
	left join cobro as cobro_errados with (nolock) on (cobro_errados.cobro_id = cobro.cobro_id
										 and cobro_errados.estado_vigencia_id = 5) 
	left join cobro as cobro_revertidos with (nolock) on (cobro_revertidos.cobro_id = cobro.cobro_id
											and cobro_revertidos.estado_vigencia_id = 8)
	left join archivo_franquicia with (nolock) on archivo_franquicia.archivo_franquicia_id = cobro.archivo_franquicia_id 
	left join archivo_pqr with (nolock) on archivo_pqr.archivo_pqr_id = poliza.archivo_pqr_id 
	left join usuario with (nolock) on archivo_pqr.usuario_id = usuario.usuario_id 
	left join	(	select 
					   poliza.poliza_id, 
					   max(cobro.cobro_id) as cobro_id 
				   from cobro with (nolock)  
				   inner join vigencia with (nolock) on cobro.vigencia_id = vigencia.vigencia_id 
				   inner join poliza with (nolock) on vigencia.poliza_id = poliza.poliza_id 
				   where cobro.estado_vigencia_id in (3,10)
				   group by poliza.poliza_id 
			   ) as ultimo_rechazo on ultimo_rechazo.poliza_id = poliza.poliza_id 
	left join	(	select 
					   cobro.cobro_id, 
					   codigo_respuesta.codigo_respuesta_id, 
					   codigo_respuesta.descripcion 
				   from cobro with (nolock) 
				   inner join codigo_respuesta with (nolock) on cobro.codigo_respuesta_id = codigo_respuesta.codigo_respuesta_id 
				   where cobro.estado_vigencia_id in (3,10)
			   ) as respuesta on respuesta.cobro_id = ultimo_rechazo.cobro_id 
	left join (	select 
					max(isnull(isnull(vigencia.fecha_fin,vigencia.fecha_corte_fin),vigencia.fecha)) as fecha_ini, 
					vigencia.poliza_id 
				from vigencia with (nolock) 
				where vigencia.estado_vigencia_id in (SELECT estado_vigencia_id FROM estado_vigencia WHERE es_recaudo = 1)
				group by vigencia.poliza_id 
			  ) as min_vigencia_no_recaudada on min_vigencia_no_recaudada.poliza_id = poliza.poliza_id
	left join (	select 
					max(vigencia.fecha_fin) as fecha_fin, 
				   max(vigencia.numero) as altura, 
					vigencia.poliza_id 
				from vigencia with (nolock) 
				where vigencia.estado_vigencia_id in (4,6,12,14,15,16) 
				group by vigencia.poliza_id 
			  ) as max_vigencia_recaudada on max_vigencia_recaudada.poliza_id = poliza.poliza_id 
	left join ( select
					vigencia.poliza_id,
					count(cobro.cobro_id) as cobros_efectivos_mes
				from vigencia with (nolock)
					left join cobro with (nolock) on cobro.vigencia_id = vigencia.vigencia_id and cobro.estado_vigencia_id in (4,12,14,15,16)
				where 1=1
					and Month(cobro.fecha_cobro) = ' + @ahora_m + '
					and Year(cobro.fecha_cobro) = ' + @ahora_y + '
				group by vigencia.poliza_id
			  ) as cobros_mes on cobros_mes.poliza_id = poliza.poliza_id 
	left join [fnSplit](''' + @sCodigo_interno + ''','','') as codin on tarjeta.codigo_interno like ''%'' + codin.item + ''%''
where	1=1 ' + @sql + @sql_fechas + '
		and	(	isnull(''' + @sCodigo_interno + ''', '''') = ''''
				or (isnull(''' + @sCodigo_interno + ''', '''') <> '''' and isnull(codin.item,'''') <> '''')
			)
group by 
	producto.codigo, 
	socio_producto.prima, 
	cliente.nombre, 
	cliente.identificacion, 
	tarjeta.numero, 
	tipo_tarjeta.descripcion,
	poliza.poliza_id,
	poliza.activa,
	poliza.numero_poliza, 
	poliza.llave_homologada,
	poliza.fecha_inicio, 
	plancardif.codigo, 
	producto.producto_id, 
	socio_producto.socio_id, 
	socio_producto.socio_producto_id, 
	producto.codigo, 
	socio_producto.prima, 
	cliente.nombre, 
	cliente.identificacion, 
	tarjeta.numero, 
	tarjeta.codigo_interno, 
	tipo_tarjeta.descripcion, 
	poliza.numero_poliza, 
	poliza.fecha_emision, 
	poliza.fecha_inicio, 
	poliza.fecha_fin,
	archivo_produccion.fecha_cargue,
	plancardif.codigo, 
	poliza.fecha_cancelacion, 
	archivo_pqr.fecha, 
	usuario.login, 
	poliza.motivo_cancelacion, 
	tipo_cancelacion.descripcion,
	tipo_cancelacion.codigo,
	poliza.valor_prima,	
	poliza.valor_sin_impuesto, 
	poliza.valor_impuesto, 
	poliza.fecha_cancelacion, 
	poliza.motivo_cancelacion, 
	poliza.valor_prima, 
	ultimo_rechazo.cobro_id, 
	respuesta.descripcion, 
	min_vigencia_no_recaudada.fecha_ini, 
	max_vigencia_recaudada.fecha_fin, 
	cobros_mes.cobros_efectivos_mes,
	--cobros_post_recaudo,
	max_vigencia_recaudada.altura,
	poliza.nota,
	poliza.origen_venta,
	poliza.codigo_asesor,
	ISNULL(poliza.amortizacion, socio_producto.prima),
	poliza.fecha_corte_inicio,
	poliza.fecha_corte_fin	
order by 
	efectivos,rechazados,pendiente_respuesta '

PRINT @script
PRINT @script1