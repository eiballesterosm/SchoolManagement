USE cobranza_P

--2690011468
--5794462047

--8153501
--8153628
--8153814
--8168755select * from motivo_reversion
DECLARE @pPolizaID AS VARCHAR(MAX) = ''
DECLARE @pNumeroPoliza AS VARCHAR(MAX) = '11363384777498V3'
--select * from poliza where indicador_recaudo = '3623165764'

IF LEN(@pPolizaID)<1 AND LEN(@pNumeroPoliza)<1
BEGIN
	PRINT 'INGRESE LOS VALORES PARA poliza_id o numero_poliza'
END


IF(LEN(@pNumeroPoliza)<1)
BEGIN
	SELECT @pNumeroPoliza = STUFF(
	(
		SELECT CONCAT(',', numero_poliza)  
		FROM poliza	with (nolock)
		WHERE poliza_id IN
		(
			SELECT value FROM STRING_SPLIT(@pPolizaID, ',')
		) FOR XML PATH('')
	),1,1,'')
END
ELSE
BEGIN
	PRINT 'NO se encontraron n�mero de p�lizas v�lidos'
END

PRINT 'N�MERO DE POLIZA'
PRINT @pNumeroPoliza

select * from archivo_pqr where archivo_pqr_id in (select archivo_pqr_id from poliza where numero_poliza = @pNumeroPoliza)

--Poliza
SELECT activa, amortizacion, * FROM poliza PO with (nolock) WHERE numero_poliza IN
(
	SELECT value FROM STRING_SPLIT(@pNumeroPoliza,',')
)

--Cliente
SELECT * FROM cliente with (nolock) WHERE cliente_id IN (
SELECT cliente_id FROM poliza PO with (nolock) WHERE numero_poliza IN
(
	SELECT value FROM STRING_SPLIT(@pNumeroPoliza,',')
)
)

--Producto
SELECT sp.prima, soc.descripcion, pr.*, sp.*
FROM poliza po with (nolock)
JOIN socio_producto sp with (nolock) ON sp.socio_producto_id = po.socio_producto_id
JOIN producto pr with (nolock) ON pr.producto_id = sp.producto_id
JOIN socio soc with (nolock) ON soc.socio_id = sp.socio_id
WHERE poliza_id IN (
		SELECT poliza_id
		FROM poliza PO with (nolock)
		WHERE numero_poliza IN (
				SELECT value
				FROM STRING_SPLIT(@pNumeroPoliza, ',')
				)
		)

--Vigencias
SELECT
'VIGENCIAS'
,vigencia.poliza_id
,vigencia_id
,vigencia.numero
,estado_vigencia.descripcion ESTADO
,estado_vigencia.es_recaudo 
,*
FROM vigencia with (nolock)
INNER JOIN estado_vigencia with (nolock) ON estado_vigencia.estado_vigencia_id = vigencia.estado_vigencia_id
WHERE poliza_id IN
(	
	SELECT poliza_id FROM poliza PO with (nolock) WHERE numero_poliza IN
	(
		SELECT value FROM STRING_SPLIT(@pNumeroPoliza,',')
	)
)
ORDER BY vigencia.poliza_id, vigencia.numero

--Cobros
SELECT
'COBROS'
,cobro.tarjeta_id
,cobro.tarjeta_cascada_id
,vigencia.poliza_id
,cobro_id
,vigencia.vigencia_id
,vigencia.numero
,estado_vigencia.descripcion ESTADO
,estado_vigencia.es_recaudo
,codigo_respuesta.descripcion CODIGO_RESPUESTA
,*
FROM cobro with (nolock)
INNER JOIN estado_vigencia with (nolock) ON estado_vigencia.estado_vigencia_id = cobro.estado_vigencia_id
INNER JOIN vigencia with (nolock) ON vigencia.vigencia_id = cobro.vigencia_id
LEFT JOIN codigo_respuesta with (nolock) ON codigo_respuesta.codigo_respuesta_id = cobro.codigo_respuesta_id
WHERE poliza_id IN
(	
	SELECT poliza_id FROM poliza PO with (nolock) WHERE numero_poliza IN
	(
		SELECT value FROM STRING_SPLIT(@pNumeroPoliza,',')
	)
)
ORDER BY vigencia.poliza_id, vigencia.numero, cobro.cobro_id

--SELECT * FROM archivo_novedad_detalle WHERE poliza_id = (SELECT poliza_id from poliza WHERE numero_poliza = @pNumeroPoliza)
--SELECT IIF(archivo_pqr.fecha <> '1900-01-01',CONVERT(VARCHAR(10),archivo_pqr.fecha),SUBSTRING(archivo_pqr.nombre, 1, 8)), * FROM archivo_pqr WHERE archivo_pqr_id = (SELECT archivo_pqr_id from poliza WHERE numero_poliza = @pNumeroPoliza)


select tipo_tarjeta.descripcion, tipo_tarjeta.es_tc, tarjeta.* from tarjeta with (nolock)
join poliza with (nolock) on poliza.tarjeta_id = tarjeta.tarjeta_id
join tipo_tarjeta with (nolock) on tipo_tarjeta.tipo_tarjeta_id = tarjeta.tipo_tarjeta_id
WHERE poliza_id IN (
		SELECT poliza_id
		FROM poliza PO with (nolock)
		WHERE numero_poliza IN (
				SELECT value
				FROM STRING_SPLIT(@pNumeroPoliza, ',')
				)
		)

SELECT tipo_tarjeta.descripcion, tipo_tarjeta.es_tc, * FROM tarjeta with (nolock)
join tipo_tarjeta with (nolock) on tipo_tarjeta.tipo_tarjeta_id = tarjeta.tipo_tarjeta_id
where cliente_id IN (

SELECT cliente_id
		FROM poliza PO with (nolock)
		WHERE numero_poliza IN (
				SELECT value
				FROM STRING_SPLIT(@pNumeroPoliza, ',')
				))