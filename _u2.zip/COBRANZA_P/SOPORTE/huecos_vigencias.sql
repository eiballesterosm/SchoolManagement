SELECT *
FROM archivo_recaudo_externo
ORDER BY archivo_recaudo_externo_id DESC

SELECT pol.poliza_id,
	vig.numero,
	ROW_NUMBER() OVER (
		PARTITION BY pol.poliza_id ORDER BY numero
		) AS RowNum
FROM poliza pol WITH (NOLOCK)
JOIN vigencia vig WITH (NOLOCK) ON vig.poliza_id = pol.poliza_id
--join cobro cob with(nolock) on cob.vigencia_id = vig.vigencia_id
WHERE pol.poliza_id IN (
		SELECT poliza_id
		FROM archivo_recaudo_externo_detalle
		WHERE archivo_recaudo_externo_id = 10224
		)
	AND vig.estado_vigencia_id IN (4)
ORDER BY pol.poliza_id,
	vig.numero
