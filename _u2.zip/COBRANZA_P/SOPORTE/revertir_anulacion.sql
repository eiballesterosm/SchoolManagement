declare @poliza_id as int = 165453

UPDATE POLIZA SET ARCHIVO_PQR_ID = NULL, FECHA_CANCELACION = NULL, MOTIVO_CANCELACION = NULL, TIPO_CANCELACION_ID = NULL
WHERE POLIZA_ID = @poliza_id

UPDATE VI SET VI.ESTADO_VIGENCIA_ID = 4 FROM VIGENCIA VI
WHERE VI.POLIZA_ID = @poliza_id
AND VI.ESTADO_VIGENCIA_ID IN (8,17,18,19)

UPDATE C SET C.ESTADO_VIGENCIA_ID = 4, C.VALOR_REVERSION = NULL, C.PORCENTAJE_REVERSION = NULL, C.FECHA_ENVIO_REVERSION = NULL
FROM COBRO C
JOIN VIGENCIA VI ON C.VIGENCIA_ID = VI.VIGENCIA_ID
WHERE VI.POLIZA_ID = @poliza_id
AND C.ESTADO_VIGENCIA_ID IN (8,17,18,19)





SELECT 
   OBJECT_NAME(f.parent_object_id) TableName,
   COL_NAME(fc.parent_object_id,fc.parent_column_id) ColName
FROM 
   sys.foreign_keys AS f
INNER JOIN 
   sys.foreign_key_columns AS fc 
      ON f.OBJECT_ID = fc.constraint_object_id
INNER JOIN 
   sys.tables t 
      ON t.OBJECT_ID = fc.referenced_object_id
WHERE 
   OBJECT_NAME (f.referenced_object_id) = 'poliza'