SELECT pfa.nombre, pro.codigo as codigo_producto
FROM plano_franquicia pfa WITH (NOLOCK)
JOIN socio_producto_franquicia spfa WITH (NOLOCK) ON spfa.franquicia_cobra_id = pfa.franquicia_id
JOIN socio_producto spr WITH (NOLOCK) ON spr.socio_producto_id = spfa.socio_producto_id
JOIN producto pro ON pro.producto_id = spr.producto_id
WHERE pfa.nombre IN
('Crediscotia Peru Mig',
'Falabella Peru',
'Banco de la Nacion Peru',
'Financiera Confianza Peru',
'CAT Nuevas 7201',
'CAT Nuevas 7202-7203-7204',
'Falabella Peru PostMigra',
'CAT Peru Nuevas',
'Crediscotia Peru',
'CAT Peru') order by pfa.nombre, pro.codigo