SELECT pfa.nombre, pro.codigo as codigo_producto, soc.descripcion as socio, soc.socio_id, spr.socio_producto_id
FROM plano_franquicia pfa WITH (NOLOCK)
JOIN socio_producto_franquicia spfa WITH (NOLOCK) ON spfa.franquicia_cobra_id = pfa.franquicia_id
JOIN socio_producto spr WITH (NOLOCK) ON spr.socio_producto_id = spfa.socio_producto_id
JOIN socio soc with(nolock) on soc.socio_id = spr.socio_id
JOIN producto pro ON pro.producto_id = spr.producto_id
WHERE pfa.nombre IN
('Occired') order by pfa.nombre, pro.codigo



SELECT *
FROM poliza pol WITH (NOLOCK)
JOIN vigencia vig WITH (NOLOCK) ON vig.poliza_id = pol.poliza_id
--JOIN cobro cob WITH (NOLOCK) ON cob.vigencia_id = vig.vigencia_id
WHERE vig.estado_vigencia_id IN (
		SELECT estado_vigencia_id
		FROM estado_vigencia WITH (NOLOCK)
		WHERE es_recaudo = 1
		)
	AND pol.socio_producto_id IN (
		934,
		950,
		951,
		952,
		930
		)
		order by pol.fecha_emision
--order by cob.fecha_cobro desc


SELECT *
FROM poliza pol WITH (NOLOCK)
JOIN vigencia vig ON vig.poliza_id = pol.poliza_id
WHERE vig.estado_vigencia_id IN (
		SELECT estado_vigencia_id
		FROM estado_vigencia WITH (NOLOCK)
		WHERE es_recaudo = 1
		)
	AND pol.socio_producto_id IN (
		559,
707,
549,
651,
652,
653
		)

