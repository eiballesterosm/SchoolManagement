USE [cobranza_P]
GO
DELETE from [dbo].[usuario] where login in ( 'villamilca','morenoja2','rabeloje', 'd35274', 'd03555', 'd56206', 'd39250', 'ballesterosed', 'd39957'
, 'D45615', '929238', 'D00381','D44758','D59110','D59566','D24422','D59111','C33076', 'C34223' )
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Carol Villamil','villamilca','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Jaime Moreno','morenoja2','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Jenny Rabelo','rabeloje','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Luis Esteban Vargas','d35274','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Carlos Gaona','d03555','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Yeiner Meri�o','d56206','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Jonathan Aponte','d39250','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Eduardo Ballesteros','ballesterosed','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
GO
INSERT INTO [dbo].[usuario]
VALUES (3,'Andres Felipe Quintana','d39957','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Andr�s Felipe Cruz','D45615','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Iv�n Ramirez','929238','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Johana G�mez','D00381','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Juan Moreno','D44758','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Edna Katherine Pe�a','D59110','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Maicol Rojas','D59566','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Sergio Duarte','D24422','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Sergio Fonseca','D59111','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Judy Sabogal','C33076','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
INSERT INTO [dbo].[usuario]
VALUES (3,'Oscar Lopez','C34223','LPZ811Jf5x+SSRF29AvuoQ==',1,null)
go
select * from [dbo].[usuario]
where login in ( 'villamilca','morenoja2','rabeloje', 'd35274', 'd03555', 'd56206', 'd39250', 'ballesterosed', 'd39957'
, 'D45615', '929238', 'D00381','D44758','D59110','D59566','D24422','D59111','C33076','C34223' )	
