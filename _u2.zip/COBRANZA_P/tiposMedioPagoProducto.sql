--Tipos de medios de pago asociados a cada producto
SELECT SP.socio_producto_id
	,GR.grupo_id
	,GR.codigo grupo_codigo
	,GR.descripcion grupo_descripcion
	,PR.producto_id
	,PR.codigo producto_codigo
	,PR.descripcion producto_descripcion
	,SO.socio_id
	,SO.codigo socio_codigo
	,SO.descripcion socio_descripcion
	,FR.franquicia_id
	,FR.codigo franquicia_codigo
	,FR.descripcion franquicia_descripcion
	,TT.tipo_tarjeta_id
	,TT.codigo tipo_tarjeta_codigo
	,TT.descripcion tipo_tarjeta_descripcion
FROM grupo GR
LEFT JOIN socio_producto SP ON SP.grupo_id = GR.grupo_id
LEFT JOIN socio_producto_franquicia SPF ON SPF.socio_producto_id = SP.socio_producto_id
LEFT JOIN producto PR ON (
		PR.producto_id = SP.producto_id
		AND SP.grupo_id = GR.grupo_id
		)
LEFT JOIN socio SO ON SO.socio_id = SP.socio_id
LEFT JOIN franquicia FR ON FR.franquicia_id = SPF.franquicia_id
LEFT JOIN tipo_tarjeta TT ON (
		TT.franquicia_id = FR.franquicia_id
		AND TT.socio_id = SO.socio_id
		)
WHERE 1 = 1
	AND PR.codigo LIKE '%8060%' --B�squeda por c�digo de producto
	--AND GR.descripcion LIKE '%bogo%'
ORDER BY GR.grupo_id
	,PR.producto_id